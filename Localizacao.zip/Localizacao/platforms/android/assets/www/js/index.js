estadosECidades = [];
var app = {
    // Application Constructor
    initialize: function () {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function () {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function () {
        app.receivedEvent('deviceready');
    },
    // Update DOM on a Received Event
    receivedEvent: function (id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};
function localizacaoOK() {
    $("#geolocation").html('Dist&acirc;ncia m&aacute;xima de voc&ecirc; at&eacute; os cinemas:');
    $("#blockmap").html('<center><select class="form-control selectwidthauto" name="distmaxima"><option value="10">10km</option><option value="15">15km</option><option value="200">200km</option><option value="300">300km</option></select></center>');
    $("#btnContinuar").css("display", "none");
    $("#submit-button").css("display", "block");
}
function pesquisaEstados() {
    var xmlhttp = new XMLHttpRequest();
    var url = "http://192.168.0.6:3000/estado/";
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var myArr = JSON.parse(xmlhttp.responseText);
            console.log(myArr.json);
            var retorno = myArr.json;
            for (var i = 0; i < retorno.length; i++) {
                estadosECidades[i] = [];
                estadosECidades[i][0] = retorno[i];
                var idestado = estadosECidades[i][0].idestado;
                pesquisaCidades(i, idestado);
            }
            popularSelectEstado();
        }

    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

}
function pesquisaCidades(i, idestado) {
    var xmlhttp = new XMLHttpRequest();
    var url = "http://192.168.0.6:3000/cidade/" + idestado;
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var myArr = JSON.parse(xmlhttp.responseText);
            var retorno = myArr.json;
            for (var a = 0; a < retorno.length; a++) {
                estadosECidades[i][a + 1] = retorno[a];
            }
            popularSelectCidade(0);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function popularSelectEstado() {
    document.getElementById("selectEstado").innerHTML = '';
    for (var i = 0; i < estadosECidades.length; i++) {
        document.getElementById("selectEstado").innerHTML += '<option value="' + estadosECidades[i][0].idestado + '">' + estadosECidades[i][0].siglaEstado + '</option>';
    }
}
function popularSelectCidade(i) {
    document.getElementById("selectCidade").innerHTML = '';
    for (var a = 1; a < estadosECidades[i].length; a++) {
        document.getElementById("selectCidade").innerHTML += '<option value="' + estadosECidades[i][a].idcidade + '">' + estadosECidades[i][a].cidade + '</option>';
    }
}
function atualizarSelectCidade(idestado) {
    document.getElementById("selectCidade").innerHTML = '';
    for (var i = 0; i < estadosECidades.length; i++) {
        if (estadosECidades[i][0].idestado == idestado) {
            for (var a = 1; a < estadosECidades[i].length; a++) {
                document.getElementById("selectCidade").innerHTML += '<option value="' + estadosECidades[i][a].idcidade + '">' + estadosECidades[i][a].cidade + '</option>';
            }
        }
    }
}
function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function (m, key, value) {
        vars[key] = value;
    });
    return vars;
}
function buscarPorCidade() {

}
function distanciaEntrePontos(latitude1, longitude1, latitude2, longitude2) {
    var raioDaTerra = 6371;
    latitude1 = latitude1 * Math.PI / 180;
    longitude1 = longitude1 * Math.PI / 180;
    latitude2 = latitude2 * Math.PI / 180;
    longitude2 = longitude2 * Math.PI / 180;
    var distLatitudes = latitude2 - latitude1;
    var distLongitudes = longitude2 - longitude1;
    var a = Math.sin(distLatitudes / 2) * Math.sin(distLatitudes / 2) + Math.cos(latitude1) * Math.cos(latitude2) * Math.sin(distLongitudes / 2) * Math.sin(distLongitudes / 2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(raioDaTerra * c * 1000);
}
cinemasAprovados = [];
filmesEmCinemas = [];
generos = [["12", "14", "16", "18", "27", "28", "35", "36", "37", "53", "80", "99", "878", "9648", "10402", "10749", "10751", "10752", "10770"], ['Aventura', 'Fantasia', 'Anima��o', 'Drama', 'Terror', 'A��o', 'Com�dia', 'Hist�ria', 'Faroeste', 'Thriller', 'Crime', 'Document�rio', 'Fic��o cient�fica', 'Mist�rio', 'M�sica', 'Romance', 'Fam�lia', 'Guerra', 'Cinema TV']];
ajaxAgora = 0;
retorno;
informacoes;
tamanho;
copiaCinemasAprovados = [];
cinemas;
idcinemas;

function buscarInformacoes() {
    informacoes = getUrlVars();
    //alert(JSON.stringify(informacoes));
    if (informacoes["latitude"] != "") {
        //Procurar por localiza��o
        //alert(informacoes["latitude"]+'<br>'+informacoes["longitude"]+'<br>'+'-5.8104571', '-35.2086688');
        var xmlhttp = new XMLHttpRequest();
        var url = "http://192.168.0.6:3000/localizacao/";
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var myArr = JSON.parse(xmlhttp.responseText);
                retorno = myArr.json;
                cinemas = JSON.parse(JSON.stringify(retorno));
                tamanho = retorno.length;
                //alert(JSON.stringify(retorno));
                verDistanciaCinema();
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    } else {
        var xmlhttp = new XMLHttpRequest();
        var url = "http://192.168.0.6:3000/cinemaporcidade/"+informacoes["cidade"];
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                var myArr = JSON.parse(xmlhttp.responseText);
                retorno = myArr.json;
                cinemas = JSON.parse(JSON.stringify(retorno));
                cinemasAprovados = [];
                for (var i = 0; i < retorno.length; i++) {
                    var lista = [retorno[i].idcinema, "Dist�ncia Indispon�vel"];
                    cinemasAprovados.push(lista);
                }
                copiaCinemasAprovados = JSON.parse(JSON.stringify(cinemasAprovados));
                //alert(JSON.stringify(cinemasAprovados));
                ligarCinemaComFilmes();
            }
        };
        xmlhttp.open("GET", url, true);
        xmlhttp.send();
    }
}
function verDistanciaCinema() {
    //alert(retorno.length);
    if (distanciaEntrePontos(informacoes["latitude"], informacoes["longitude"], retorno[0].latitude, retorno[0].longitude) <= informacoes["distmaxima"] * 1000) {
        //alert("T� aqui");
        var requestGoogle = new XMLHttpRequest();
        var url = 'https://maps.googleapis.com/maps/api/distancematrix/json?origins=' + informacoes["latitude"] + ',' + informacoes["longitude"] + '&destinations=' + retorno[0].latitude + ',' + retorno[0].longitude + '&language=pt-BR&key=AIzaSyBXluJ5mRYjycCycD0qVU1M_mvavsC1r1w';
        requestGoogle.onreadystatechange = function () {
            if (requestGoogle.readyState == 4 && requestGoogle.status == 200) {
                //alert("T� nesse lugar");
                distancia = JSON.parse(requestGoogle.responseText).rows[0].elements[0].distance;
                if (distancia.value <= informacoes["distmaxima"] * 1000) {
                    //alert(distancia.value+': Cinema '+(tamanho - retorno.length + 1)+" aprovado");
                    var lista = [retorno[0].idcinema, distancia.text];
                    cinemasAprovados.push(lista);
                    //alert("Tanmanho: "+cinemasAprovados.length);
                    //alert("T� nesse canto");
                    //alert("Ajax Agora: "+ajaxAgora);
                } else {
                    //alert(distancia.value+': reprovada1');
                }
                retorno.shift();
                proximoLoopDistanciaCinema();
            }
        };
        requestGoogle.open("GET", url, true);
        requestGoogle.send();
    } else {
        //alert("T� acul�");
        var distancia = distanciaEntrePontos(informacoes["latitude"], informacoes["longitude"], retorno[0].latitude, retorno[0].longitude);
        //alert(distancia.value+': reprovada2');
        retorno.shift();
        proximoLoopDistanciaCinema();
    }
}
function proximoLoopDistanciaCinema() {
    if (retorno.length != 0) {
        verDistanciaCinema();
    } else {
        //alert(JSON.stringify(cinemasAprovados));
        copiaCinemasAprovados = JSON.parse(JSON.stringify(cinemasAprovados));
        ligarCinemaComFilmes();
    }
}

function ligarCinemaComFilmes() {
    //alert("Eu t� aqui e o tamanho da array � "+copiaCinemasAprovados.length);
    var requestFilmes = new XMLHttpRequest();
    var url = 'http://192.168.0.6:3000/filme/' + copiaCinemasAprovados[0][0];
    requestFilmes.onreadystatechange = function () {
        if (requestFilmes.readyState == 4 && requestFilmes.status == 200) {
            //alert("Deu certo!");
            var filmes = JSON.parse(requestFilmes.responseText).json;
            inserirFilmes(filmes);
            cinemasAprovados[indexCinema()][2] = [];
            for (var d = 0; d < filmes.length; d++) {
                //alert(d);
                //alert(index);
                cinemasAprovados[indexCinema()][2][d] = filmes[d].idfilme;
                //alert(cinemasAprovados[indexCinema()][2][d]);
            }
            copiaCinemasAprovados.shift();
            //alert("Tamanho: "+cinemasAprovados.length);
            proximoLoopLigarCinemasComFilmes();
        }
    };
    requestFilmes.open("GET", url, true);
    requestFilmes.send();
}
function indexCinema() {
    return (cinemasAprovados.length) - (copiaCinemasAprovados.length);
}
function proximoLoopLigarCinemasComFilmes() {
    if (copiaCinemasAprovados.length != 0) {
        ligarCinemaComFilmes();
    } else {
        $("#telaCarregando").css("display", "none");
        //$("#resultados").html(JSON.stringify(cinemasAprovados) + JSON.stringify(filmesEmCinemas));
        popularCinemas();
        //alert(cinemasAprovados.length);
        //$("#txtCinemas").val(JSON.stringify(cinemasAprovados));

        //document.forms["form"].submit();
    }
}
function inserirFilmes(filmes) {
    for (var i = 0; i < filmes.length; i++) {
        var filmeRegistrado = false;
        for (var a = 0; a < filmesEmCinemas.length; a++) {
            if (filmesEmCinemas[a][0] == filmes[i].idfilme) {
                filmeRegistrado == true;
                break;
            }
        }
        if (!filmeRegistrado) {
            filmesEmCinemas.push([filmes[i].idfilme, filmes[i].avaliacao, filmes[i].nomeDoFilme, filmes[i].classifEtaria, filmes[i].sinopse, filmes[i].imagem, filmes[i].generos.split(", ")]);
        }
    }
}

function popularCinemas() {
    var cinema;
    var idcinemaslocal = [];

    //alert("T� aqui!");
    for (var i = 0; i < cinemasAprovados.length; i++) {
        idcinemaslocal.push(cinemasAprovados[i][0]);
        //alert('i: '+i);
        for (var a = 0; a < cinemas.length; a++) {
            //alert('a: '+a);
            //alert(JSON.stringify(cinemas[a]));
            //alert('Nesse lugar:' + cinemas[a].idcinema + ' - ' + cinemasAprovados[i][0]);
            if (cinemas[a].idcinema == cinemasAprovados[i][0]) {
                cinema = cinemas[a];
                break;
            }
            //alert('Aqui:' + cinema.idcinema + ' - ' + cinema.nome);

        }
        //alert(cinema.idcinema + ' - ' + cinema.nome);
        document.getElementById("SelectCinema").innerHTML += '<option value="' + cinema.idcinema + '">' + cinema.nome + '</option>';
    }
    idcinemas = JSON.parse(JSON.stringify(idcinemaslocal));
    popularFilmes(idcinemaslocal);
}
function popularFilmes(idcinemas) {
    document.getElementById("SelectFilmes").innerHTML = '<option value="*">Selecione</option>';
    var filmes = [];
    var generosAtuais = [];
    //alert(JSON.stringify(idcinemas));
    var d;
    for (var c = 0; c < idcinemas.length; c++) {
        for (d = 0; d < cinemasAprovados.length; d++) {
            if (cinemasAprovados[d][0] == idcinemas[c]) {
                d = cinemasAprovados[d][2];
                break;
            }
        }
        //alert(d);
        for (var b = 0; b < d.length; b++) {
            //alert('E aqui!');
            //alert ('IndexOf: '+filmes.indexOf(d[b]));
            if (filmes.indexOf(d[b]) == -1) {
                //alert('IdFilme: '+d[b]);
                filmes.push(d[b]);
            }
        }
    }
    //alert(JSON.stringify(filmes));
    var lista = [];
    for (var e = 0; e < filmes.length; e++) {
        for (var f = 0; f < filmesEmCinemas.length; f++) {
            if (filmesEmCinemas[f][0] == filmes[e]) {
                for (var a = 0; a < filmesEmCinemas[f][6].length; a++) {
                    if (generosAtuais.indexOf(filmesEmCinemas[f][6][a]) == -1) {
                        generosAtuais.push(filmesEmCinemas[f][6][a]);
                    }
                }
                lista.push(filmes[e] + "")
                document.getElementById("SelectFilmes").innerHTML += '<option value="' + filmes[e] + '">' + filmesEmCinemas[f][2] + '</option>';
                break;
            }
        }
    }
    popularGeneros(generosAtuais);
}
function popularGeneros(generosAtuais) {
    document.getElementById("SelectGenero").innerHTML = '<option value="*">Selecione</option>';
    //alert(JSON.stringify(generosAtuais));
    for (var a = 0; a < generosAtuais.length; a++) {
        document.getElementById("SelectGenero").innerHTML += '<option value="' + generosAtuais[a] + '">' + generos[1][generos[0].indexOf(generosAtuais[a])] + '</option>';
    }
    $("#TelaApp").css("display", "block");
}
function mudarBuscaNomeOuGenero() {
    if ($('input[name="optradio"]:checked').val() == 0) {
        $("#formGeneros").hide();
        $("#formFilmes").show();
        $("#SelectGenero").val("*");
    } else {
        $("#formGeneros").show();
        $("#formFilmes").hide();
        $("#SelectFilmes").val("*");
    }
}

function mudarEstrelas(num) {
    for (var c = 1; c < 6; c++) {
        $("#estrela" + c).attr("src", "img/Estrela.png");
    }
    for (var i = 1; i < num; i++) {
        $("#estrela" + i).attr("src", "img/EstrelaSelecionada.png");
    }
    notaminima = --num;
}
function formataData(entrada) {
    dArr = entrada.split("-");
    return dArr[2]+"/"+dArr[1];
}
numerodePesquisas = 0;
function buscarSessoes(pesquisas, notaminima) {
    var requestSessoes = new XMLHttpRequest();
    var url = 'http://192.168.0.6:3000/sessoes/';
    if ($("#SelectCinema").val() == "*") {
        var texto = "";
        for(var i = 0; i < cinemasAprovados.length; i++) {
            if (texto != "") {
                texto += ","
            }
            texto += cinemasAprovados[i][0];
        }
        url += texto + "/";
    } else { url += $("#SelectCinema").val() + "/"; }
    
    url += $("#SelectGenero").val() + "/";
    url += $("#SelectFilmes").val() + "/";
    if ($("#horaminima").val()) {
        url += $("#horaminima").val().replace(":", "h");
    } else {
        url += '*';
    }
    url += "/";
    if ($("#horamaxima").val()) {
        url += $("#horamaxima").val().replace(":", "h");
    } else {
        url += '*';
    }
    url += "/";
    url += $("#SelectTipo").val() + "/";
    url += $("#SelectClasificacao").val() + "/";
    if ($("#PrecoMaximo").val()) {
        url += $("#PrecoMaximo").val();
    } else {
        url += '*';
    }
    url += "/";
    var nota = isNaN(notaminima) ? "0" : notaminima;
    url += nota + "/";
    url += (pesquisas * 10).toString();
    //alert(url);
    requestSessoes.onreadystatechange = function () {
        if (requestSessoes.readyState == 4 && requestSessoes.status == 200) {
            //alert("Estou Aqui!");
            numerodePesquisas++;
            var sessoes = JSON.parse(requestSessoes.responseText).json;
            mostrarResultados(sessoes);
            //alert("Tamanho: "+cinemasAprovados.length);
        }
    };
    requestSessoes.open("GET", url, true);
    requestSessoes.send();
}

function mostrarResultados(lista) {
    var todasAsSessoesCarregadas = false;
    $("#botaoPesquisaNovamente").remove();
    var comprimento = lista.length - 1;
    //alert(lista[0].imagem)
    if (lista.length != 0) {
        for (var i = 0; i < lista.length && i < 10; i++) {
            var htmlParaAdicionar = $("#resultados").html();
            htmlParaAdicionar += '<div class="row resultado"><table><tr><td>';
            htmlParaAdicionar += '<img align="left" src="' + lista[i].imagem + '" width="'+$(window).width()/3+'" class="img-rounded"></td>';
            htmlParaAdicionar += '<td><table><tr><td><h4>' + lista[i].filme + '</h4></td></tr>';
            htmlParaAdicionar += '<tr><td><h4>' + formataData(lista[i].data) + ' - ' + lista[i].horario + '</h4></td></tr>';
            htmlParaAdicionar += '<tr><td><h4>' + lista[i].cinema + '</h4></td></tr>';
            htmlParaAdicionar += '<tr><td><table><tr><td><h3><span class="label label-default">' + lista[i].tipo_exibicao.substr(0, 3).toUpperCase() + '</span></h3></td>';
            htmlParaAdicionar += '<td><img align="bottom" src="img/' + lista[i].classificacao + '.png" height="32" width="32" class="img-rounded"></td>';
            if (lista[i].e_3d) {
                htmlParaAdicionar += '<td><img align="bottom" src="https://lh4.ggpht.com/YXzBmS7AyZN689K9Yif1tdyK5VnvXS7CGIIu62R6W7V3SdWuzMHnHTUyKE_8vabaPe8P=w300" width="32" height="32" class="img-rounded"></td>';
            }
            htmlParaAdicionar += '</tr></table></td></tr></table></tr></table></div>';
            $("#resultados").html(htmlParaAdicionar);
            
            if (i == comprimento) {
                todasAsSessoesCarregadas = true;
            }
        }
        if (!todasAsSessoesCarregadas) {
            var htmlParaAdicionar = $("#resultados").html();
            htmlParaAdicionar += '<center><button type="button" id="botaoPesquisaNovamente" class="btn btn-default" onClick="buscarSessoes(numerodePesquisas)">Carregar mais sess�es</button></center>';
            $("#resultados").html(htmlParaAdicionar);
        }
    } else {
        $("#resultados").html("Nenhuma sess�o encontrada");
    }
}
/*
 for (d = 0; d < filmesEmCinemas.length; d++) {
 if (filmesEmCinemas[d].idfilme == filmes[b]) {
 d = filmesEmCinemas[d].nomeDoFilme;
 break;
 }
 }
 
 
 
 
 * 
 *         alert('i: '+i);
 for (var a = 0; a < cinemas.length; a++) {
 alert('a: '+a);
 alert(JSON.stringify(cinemas[a]));
 if (cinemas[a].idcinema == cinemasAprovados[i][0]) {cinema = cinemas[a];alert('Aqui:'+cinema.idcinema+' - '+cinema.nome);}
 alert(cinema.idcinema+' - '+cinema.nome);
 document.getElementById("SelectCinema").innerHTML += '<option value="'+cinema.idcinema+'">'+cinema.nome+'</option>';
 }
 function modelarbanco(tx) {
 tx.executeSql('CREATE TABLE IF NOT EXISTS estado (idestado INTEGER PRIMARY KEY NOT NULL, siglaEstado TEXT NOT NULL)');
 tx.executeSql('CREATE TABLE IF NOT EXISTS cidade (idcidade INTEGER PRIMARY KEY NOT NULL, nomeCidade TEXT NOT NULL, idestado INTEGER NOT NULL, FOREIGN KEY(idestado) REFERENCES estado(idestado))');
 tx.executeSql('CREATE TABLE IF NOT EXISTS endereco (idendereco INTEGER PRIMARY KEY NOT NULL, bairro TEXT NOT NULL, logradouro TEXT NOT NULL, numero INTEGER NOT NULL, idcidade INTEGER NOT NULL, FOREIGN KEY(idcidade) REFERENCES cidade(idcidade))');
 tx.executeSql('CREATE TABLE IF NOT EXISTS cinema (idcinema INTEGER PRIMARY KEY NOT NULL, nomeCinema TEXT NOT NULL, latitude TEXT NOT NULL, longitude TEXT NOT NULL, telefone TEXT NOT NULL, idendereco INTEGER NOT NULL, FOREIGN KEY(idendereco) REFERENCES endereco(idendereco))');
 tx.executeSql('CREATE TABLE IF NOT EXISTS filme (idfilme INTEGER PRIMARY KEY NOT NULL, avaliacao DOUBLE NOT NULL, nomeDoFilme TEXT NOT NULL, classificacaoEtaria INTEGER NOT NULL, sinopse TEXT NOT NULL, diretor TEXT NOT NULL, elenco TEXT NOT NULL)');
 tx.executeSql('CREATE TABLE IF NOT EXISTS genero (idgenero INTEGER PRIMARY KEY NOT NULL, nomeGenero TEXT NOT NULL)');
 tx.executeSql('CREATE TABLE IF NOT EXISTS filme_genero (idfilme INTEGER NOT NULL, idgenero INTEGER NOT NULL, FOREIGN KEY(idfilme) REFERENCES filme(idfilme), FOREIGN KEY(idgenero) REFERENCES genero(idgenero)');
 }
 function errobanco(err) {
 alert("Error processing SQL: "+err.code);
 }
 function sucessobanco() {
 alert("Sucesso!");
 }
 */